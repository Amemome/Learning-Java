/* Lab번호: 2
 * 분반번호: 1분반
 * 제출일: 2025-04-01
 * 학번: 32241484
 * 이름: 류지성
 */
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    // 입력을 받기 위한 Scanner 객체를 만든다.
    static Scanner scan = new Scanner(System.in);

    // 임의의 값을 생성하기 위한 Random 객체를 만든다.
    static Random random = new Random();

    // 분수의 덧셈, 뺄셈, 곱셈, 나눗셈을 하는 fraction 함수. 4개의 실수(첫번째 분자, 분모, 두번째 분자 ,분모) 를 받는다.
    public static void fraction(double num1, double den1, double num2, double den2) {
        // 분수 덧셈
        double addNum = (num1 * den2) + (num2 * den1);
        double commonDen = den1 * den2;
        System.out.printf("Fraction Addition: %.1f/%.1f + %.1f/%.1f = %.1f/%.1f\n",
                num1, den1, num2, den2, addNum, commonDen);

        // 분수 뺄셈
        double subNum = (num1 * den2) - (num2 * den1);
        System.out.printf("Fraction Subtraction: %.1f/%.1f - %.1f/%.1f = %.1f/%.1f\n",
                num1, den1, num2, den2, subNum, commonDen);

        // 분수 곱셈
        double mulNum = num1 * num2;
        double mulDen = den1 * den2;
        System.out.printf("Fraction Multiplication: %.1f/%.1f * %.1f/%.1f = %.1f/%.1f\n",
                num1, den1, num2, den2, mulNum, mulDen);

        // 분수 나눗셈
        double divNum = num1 * den2;
        double divDen = den1 * num2;
        System.out.printf("Fraction Division: %.1f/%.1f / %.1f/%.1f = %.1f/%.1f\n",
                num1, den1, num2, den2, divNum, divDen);
    }


    // min 이랑 max 를 받아서 range 안의 랜덤 숫자를 반환한다.
    static int getRandomIntBetween(int min, int max) {
        return random.nextInt(max - min + 1) + min;
    }

    // 짝수인지 boolean 값을 반환한다.
    static boolean isEven(int num) {
        return num % 2 == 0;
    }

    // 3의 배수인지 boolean 값을 반환한다.
    static boolean isMultiplesOfThree(int num) {
        return num % 3 == 0;
    }

    // 소수인지 boolean 값을 반환합니다. sqrt(n) 까지 나누어지는지 확인하는 방법을 사용한다.
    static boolean isPrime(int num) {
        if(num < 2) return false;
        // i*i <= num 조건으로 sqrt(n) 까지 반복
        for(int i = 2; i * i <= num; i++) {
            if(num % i == 0) return false;
        }
        return true;
    }

    // task2 실행함수이다.
    static void checkNumber(int num) {

        // 짝수 검사.
        if(isEven(num)) {
            System.out.println(num + " is even number");
        } else {
            System.out.println(num + " is odd number");
        }

        // 3의 배수 검사
        if(isMultiplesOfThree(num)) {
            System.out.println(num + " is Multiple of Three");
        } else {
            System.out.println(num + " is not Multiple of Three");
        }

        // 소수 검사
        if(isPrime(num)) {
            System.out.println(num + " is a prime number");
        } else {
            System.out.println(num + " is not a prime number");
        }
    }

    // 분할정복을 사용한 빠른 거듭제곱 방법을 사용하여 거듭제곱을 계산하는 함수다.
    static long powerCalculation(long base, long exponent) {

        // base case / 재귀호출의 끝
        if(exponent == 1) {
            return base;
        }
        long half = 0;
        // 지수를 절반으로 줄여 재귀호출
        half = powerCalculation(base, exponent/2);

        // 지수가 짝수가 아니면 base 한번 더 곱해준다.
        if(exponent % 2 == 1) {
            return half * half * base;
        } else {
            return half * half;
        }
    }

    // user의 input 을 받는 함수다. message 를 인자로 받아 원하는 메세지를 넣을 수 있어 재사용성이 높다.
    // 범위를 벗어난 input 이 들어오면 다시 input 을 받는다.
    static int getUserInputBetween(String message,int min,int max) {
        // 입력받을 값
        int value = 0;

        while (true) {
            System.out.printf("%s, [%d-%d]: ", message, min, max);
            // try catch 문으로 예외처리를 해줍니다. (문자열 입력 방지)
            try {
                // 줄을 받고 정수로 변환합니다.
                value = Integer.parseInt(scan.nextLine());

                // 범위 내에 있으면 반복문을 탈출합니다.
                if(min <= value && value <= max) {
                    break;
                }
            } catch (Exception error) {
                System.out.println(error+"! Please re-enter!");
            }
        }
        System.out.println(value);
        return value;
    }

    // 입력받은 수에 대해 구구단을 출력하는 함수다.
    // getUserInputBetween을 통해 2~20 사이 숫자를 입력받고, 해당 단의 구구단을 출력한다.
    static void multiplicationTable() {
        int randIntBetween2and20 = getUserInputBetween("Please enter a number between",2,20);
        System.out.printf("Multiplication Table for %d:\n", randIntBetween2and20);
        for(int i = 1; i < 10; i++) {
            System.out.printf("%d x %d = %d\n", randIntBetween2and20 , i , randIntBetween2and20 * i);
        }
    }

    // RGB 값을 가진 Color 열거형(enum).
    // 각 색상은 r, g, b의 정수 값을 멤버로 갖는다.
    enum Color {
        RED(255, 0, 0),
        GREEN(0, 255, 0),
        BLUE(0, 0, 255),
        YELLOW(255, 255, 0),
        WHITE(255, 255, 255),
        BLACK(0, 0, 0),
        MAGENTA(255,0,255);

        final int r,g,b;

        Color(int r,int g,int b) {
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }

    // 입력된 r, g, b 값이 Color enum 중 하나와 일치하는 경우 해당 색을 반환한다.
    // 일치하는 색이 없으면 null 반환
    static Color getColor(int r, int g, int b) {

        // Color.values() 로 enum 에 정의된 값들을 전부 확인합니다.
        for(Color color : Color.values()) {
            if(color.r == r && color.g == g && color.b == b) {
                return color;
            }
        }
        return null;
    }

    // 소수점 이하 자리수를 원하는 만큼 반올림하여 반환한다.
    static double decimalValue(double num, int decimalPlace) {
        // 소수부분만 남기기 위해서 Math.floor을 적용한 num을 빼줍니다.
        double result = num - Math.floor(num);

        // 어느 자리에서 반올림 할지 계산을 위해서 10^자리수 로 mover 을 정의합니다.
        double mover = Math.pow(10,decimalPlace);

        // result 는 mover 에서 계산한 값을 가지고 올리고 반올림을 한 후 내린 값 입니다.
        // Math.round 함수는 자리수 지정이 안되기 때문에 mover 를 정의하여 올렸다가 내려줘야합니다.
        result = Math.round(result * mover) / mover;
        return result;
    }

    // 모음만 강조하는 함수. 문자열을 입력으로 받는다.
    static String emphasizeVowels(String str) {

        // 반복적인 String 붙이기 작업을 수행하기 위해 StringBuilder 를 사용한다.
        StringBuilder stringBuilder = new StringBuilder();

        // 문자열 전체를 순회하며 각 문자를 char 형 변수로 뽑아낸다.
        for(int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            // isVowel 함수로 모음인지 검사를 한 후, 대문자나 소문자로 바꾼다.
            if(isVowel(c)) {
                stringBuilder.append(Character.toUpperCase(c));
            } else {
                stringBuilder.append(Character.toLowerCase(c));
            }
        }

        // 반환값은 String 이므로, toString 메서드를 사용하여 반환한다.
        return stringBuilder.toString();
    }

    // 모음인지 검사하는 함수
    static boolean isVowel(char c) {
        return  c == 'a' ||
                c == 'e' ||
                c == 'i' ||
                c == 'o' ||
                c == 'u';
    }

    // 시 분 초 를 받아서 몇 초 인지 환산하여 출력하는 함수.
    static void convertToSeconds (int hours, int minutes, int seconds) {
        int totalSeconds = hours * 3600 + minutes * 60 + seconds;
        System.out.printf("%d hours, %d minutes, %d seconds converted to total seconds is: %d sec\n", hours, minutes, seconds, totalSeconds);
    }

    // 초를 받아서 시 분 초로 환산하여 출력하는 함수.
    static void convertFromSeconds (int seconds) {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int finalSeconds = seconds % 60;
        System.out.printf("%d seconds is: %d hours, %d minutes, %d seconds\n", seconds, hours, minutes, finalSeconds);
    }

    // 입력된 row 와 col 의 수 만큼 좌석번호를 생성해 2차원 배열을 반환. 좌석 번호는 RnCm 형식.
    static String[][] creatingSeatingChart (int rows, int cols) {
        String[][] seatingChart = new String[rows][cols];
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < cols; j++) {
                seatingChart[i][j] = String.format("R%dC%d",i+1,j+1);
            }
        }
        return seatingChart;
    }

    // 2차원 좌석표를 출력한다. 2중 for 문으로 순회하며 출력한다.
    static void printSeatingChart (String[][] seatingChart) {
        for (int i = 0; i < seatingChart.length; i++) {
            for (int j = 0; j < seatingChart[i].length; j++) {
                System.out.print(seatingChart[i][j]+" ");
            }
            System.out.println();
        }
    }

    // 사용자에게 행과 열을 입력받아 좌석표를 출력하고, 'q' 키를 누를 때 까지 계속 반복하는 함수.
    static void seatingChart () {
        String input = "\0";
        String isContinue = "\0";
        // 문자열을 받고 이게 q 인지 검사를 한다. 메서드로 비교를 하고, 대소문자 무시를 합니다. 앞에 ! 을 붙임으로서 notEqual 의미를 갖습니다.
        while (!isContinue.equalsIgnoreCase("q")) {
            System.out.print("Please enter row column number [e.g. 5 7]:");
            input = scan.nextLine();
            // 사용자로부터 받은 입력의 예외처리를 하기 위해서 try 문을 사용합니다.
            try {
                // " " 공백으로 구분된 입력을 split 하여 tokenize 합니다.
                String[] tokens = input.split(" ");
                int rows = Integer.parseInt(tokens[0]);
                int cols = Integer.parseInt(tokens[1]);
                // String[][] 좌석표를 정의합니다
                String[][] seatingChart;
                // creatingSeatingChart 함수를 호출하여 좌석표를 만듭니다.
                seatingChart = creatingSeatingChart(rows, cols);
                // printSeatingChart 함수를 호출하여 출력합니다.
                printSeatingChart(seatingChart);
            } catch(Exception error) {
                System.out.println(error+"! 입력이 잘못 되었습니다!");
            }
            // 입력값을 isContinue에 넣습니다.
            System.out.print("Press 'q' to exit the process OR any-key continue to: ");
            isContinue = scan.nextLine();
        }
    }

    // 가변인자로 여러개의 숫자를 받고 그 숫자에 대한 정보를 출력하는 함수.
    static void informationOfNumber (int... numbers) {

        // 비교를 위해 max 에는 최소값을, min 에는 최대값을 초기화합니다.
        int sum = 0, max = Integer.MIN_VALUE, min = Integer.MAX_VALUE;
        double average, median = 0;

        // 범위 기반 반복문을 사용하여 가변인자로 받은 숫자들을 처리합니다. 전체 합이랑, 최소 최대값을 구합니다.
        for (int number : numbers) {
            sum += number;
            if(number > max) max = number;
            if(number < min) min = number;
        }

        // 배열의 멤버변수를 사용하여 평균을 구합니다. 정확한 값을 위해 sum 을 dobule 로 명시적 캐스팅을 해줍니다.
        average = (double) sum / numbers.length;

        // 배열의 중간의 인덱스를 찾습니다.
        int mid = numbers.length / 2;

        // 원본 배열을 정렬 전 보존을 해놓고, 복사본을 정렬합니다.
        int[] sortedNumbers = Arrays.copyOf(numbers, numbers.length);
        Arrays.sort(sortedNumbers);

        // 중앙값을 계산합니다. 길이가 홀수냐 짝수냐에 따라서 구하는 값이 달라집니다.
        if(sortedNumbers.length % 2 == 0) {
            median = (sortedNumbers[mid - 1] + sortedNumbers[mid + 1]) / 2.0;
        } else {
            median = sortedNumbers[mid - 1];
        }

        // 정보들을 출력합니다.
        System.out.println("총합: " + sum);
        System.out.println("평균: " + average);
        System.out.println("최댓값: " + max);
        System.out.println("최솟값: " + min);
        System.out.println("중앙값: " + median);
    }

    // 코드를 실행할 Main 함수이다.
    public static void main(String[] args) throws Exception {
        
        //task1
        fraction(3.0,7.0,2.0,15.0);
        fraction(31.0,73.0,12.0,145.0);
        fraction(3.0,79.0,28.0,11.0);

        //task2
        int randInt = getRandomIntBetween(1, 100);
        checkNumber(randInt);

        //task3
        long base = getRandomIntBetween(1, 10);
        long exponent = getRandomIntBetween(1, 6);
        long result = powerCalculation(base, exponent);
        System.out.println("[Power Calculation using Fast Exponentiation] " + base + " ^ " + exponent + " = " + result);

        //task4
        multiplicationTable();

        //task5
        System.out.println("getColor(255,0,0) --> " + getColor(255,0,0));
        System.out.println("getColor(0,255,0) --> " + getColor(0,255,0));
        System.out.println("getColor(0,0,255) --> " + getColor(0,0,255));
        System.out.println("getColor(255,255,0) --> " + getColor(255,255,0));
        System.out.println("getColor(255,255,255) --> " + getColor(255,255,255));
        System.out.println("getColor(0,0,0) --> " + getColor(0,0,0));
        System.out.println("getColor(255,0,255) --> " + getColor(255,0,255));

        //task6
        System.out.println("3.14159265 Decimal5 value: " + decimalValue(3.14159265, 5));
        System.out.println("5.983 Decimal2 value: " + decimalValue(5.983, 2));

        //task7
        System.out.println(emphasizeVowels("aStringThatLooksLikeThis"));
        System.out.println(emphasizeVowels("Hello World, Java!"));

        //task8
        convertToSeconds(2, 30, 15);
        convertFromSeconds(9015);
        convertToSeconds(5, 32, 11);
        convertFromSeconds(13205);
        //task9
        seatingChart();

        //task10
        informationOfNumber(1, 3, 6, 3, 7, 2);
    }
}
