/* Lab번호: MidtermExtra
 * 분반번호: 1분반
 * 제출일: 2025-04-24
 * 학번: 32241484
 * 이름: 류지성
 */
public enum FigureType { // 도형의 유형에 대한 Enum
    SQUARE, // 정사각형
    RECTANGLE, // 직사각형
    RHOMBUS, // 마름모
    PARALLELOGRAM, // 평행사변형
    TRAPEZOID; // 사다리꼴
}
